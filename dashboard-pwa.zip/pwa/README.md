# 이재원 개인 대시보드 — PWA

홈 화면에 추가해서 앱처럼 쓰는 대시보드입니다. 설치 파일도, 스토어 등록도 필요 없어요.

## 들어 있는 파일

| 파일 | 하는 일 |
|---|---|
| `index.html` | 앱 본체. 화면·계산·탭 전부 여기에 있습니다 |
| `data.json` | **매일 바뀌는 데이터.** 앱은 열 때마다 이 파일을 다시 읽습니다 |
| `manifest.webmanifest` | 앱 이름·아이콘·전체화면 설정 |
| `sw.js` | 서비스워커. 오프라인에서도 열리게 해줍니다 |
| `icon-*.png` | 홈 화면 아이콘 |

`index.html` 안에 `data.json`의 사본이 한 벌 박혀 있어서, 인터넷 없이 파일만 열어도 화면이 뜹니다.
연결되면 원격 `data.json`으로 덮어써요.

---

## 1. GitHub Pages에 올리기 (한 번만)

1. github.com에서 **New repository** → 이름은 아무거나 (예: `dashboard`) → **Public** 선택 → Create
2. 만들어진 레포에서 **Add file → Upload files**
3. 이 폴더 안의 파일을 **전부** 끌어다 놓고 **Commit changes**
4. **Settings → Pages** → Source를 **Deploy from a branch**, 브랜치는 `main` / `/ (root)` → Save
5. 1~2분 뒤 주소가 나옵니다: `https://<아이디>.github.io/dashboard/`

> Public 레포여야 Pages가 무료로 켜집니다. 이 안에 성적이나 대학 목록이 들어가면
> 인터넷에 공개된다는 뜻이니, 민감하다 싶으면 Private 레포 + 다른 호스팅을 쓰세요.

## 2. 홈 화면에 추가

**안드로이드 (Chrome)** — 주소로 접속 → 우측 상단 ⋮ → **앱 설치** 또는 **홈 화면에 추가**

**아이폰 (Safari)** — 주소로 접속 → 하단 공유 버튼 → **홈 화면에 추가**
(아이폰은 반드시 Safari로 해야 합니다. Chrome에서는 옵션이 안 나와요.)

추가하면 주소창 없는 전체화면으로 뜨고, 비행기 모드에서도 열립니다.

---

## 3. 매일 갱신

Claude가 매일 아침 7시에 최신 `data.json`을 만들어 보내줍니다.
받은 파일을 레포에 덮어쓰면 끝이에요:

> 레포에서 `data.json` 클릭 → 연필 아이콘 옆 **⋯ → Upload files**로 같은 이름 파일을 올리고 Commit

앱은 열 때마다 새 `data.json`을 가져오므로, 커밋하고 1분쯤 뒤 앱을 다시 열면 반영됩니다.

**날짜 관련 숫자는 갱신 없이도 항상 정확합니다.** D-day, 학년도 진행률, "며칠 전" 표시는
전부 앱이 열릴 때 기기 시계로 다시 계산해요. `data.json`이 필요한 건 AutoSub 수치,
Drive 파일 목록, 성적, 지원 대학처럼 제가 채워 넣는 값들입니다.

---

## 직접 고치고 싶을 때

`data.json`만 손대면 됩니다. 자주 건드릴 곳:

```jsonc
"subjects": [
  { "name": "국어", "color": "var(--s1)", "grades": [2, 2, null, null] },
  //                                        ↑ 3월 학평, 6월 모평, 9월 모평, 수능 순서
]

"susi": [
  { "univ": "광운대", "type": "학생부종합" },   // 1지망
  null, null, null, null, null                  // null = 빈 칸
]
```

`index.html`을 고쳤다면 `sw.js` 첫 줄의 `dash-v1`을 `dash-v2`로 올리세요.
안 그러면 서비스워커가 옛날 화면을 계속 보여줍니다.
